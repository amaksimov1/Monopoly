package ru.welokot.monopoly.di

import dagger.Module

@Module
class AppModule

/**
 * Здесь хранятся все зависимости
 * уровня приложения.
 * Например Room, Retrofit
 * и пр.
 */